import React from "react";
import { Link } from "react-router-dom";
import "./login.css";

function Loginpg(){
  const navigate = useNavigate();
  const handleLoginClick = (e) => {
    e.preventDefault();  
    navigate("/mainpg");  
  };
  return(
    <div className="login-container">
      <div className="signup-box">
        <h1>Word Puzzle</h1>
        <h2>LOG IN</h2>
        <form>
          <label>Email :</label>
          <input type="email"/>

          <label>Password :</label>
          <input type="password"/>

          <button type="submit" onClick={handleLoginClick}>LOG IN</button>
        </form>
        <p>
          If you don't have an account{" "}
          <Link to="/">Login</Link> here
        </p>
        <p>
          <Link to=" ">Forgot Password</Link>
        </p>
      </div>
    </div>
  );
}

export default Loginpg
