import React from "react";
import { Link } from "react-router-dom";
import "./home.css"

function HomePGX(){
  return(
    <div className="container">
      <div className="home-signup-box">
        <h1>Word Puzzle</h1>
        <h2>SIGN UP</h2>
        <form>
          <label>Name :</label>
          <input type="text"/>

          <label>Email :</label>
          <input type="email"/>

          <label>Password :</label>
          <input type="password"/>

          <button type="submit">Sign Up</button>
        </form>
        <p>
          If you already have an account{" "}
          <Link to="/login">Login</Link> here
        </p>
      </div>
    </div>
  );
}

export default HomePGX
