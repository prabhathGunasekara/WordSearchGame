import React from "react";
import { Link } from "react-router-dom";
import "./mainpg.css";

function MainPG(){
    return(
        <div className="main-container">
        <div className="mainpgcontainer">
            <h1>Word Puzzle</h1>
            <div className="play-button-container">
            <div className="play-button">
            <span>▶</span>
            </div>
            </div>
            <p className="play-txt">PLAY</p>
            <button className="leaderboard-button">Leader board</button>
        </div>
        </div>
        
    );

}

export default MainPG