import React from "react";
import { BrowserRouter as Router, Routes, Route } from "react-router-dom";
import HomePGX from "./home";
import Loginpg from "./login";
import MainPG from "./mainpg";

function App() {
  return (
    <Router>
      <Routes>
        <Route path="/" element={<HomePGX />} />
        <Route path="/login" element={<Loginpg />} />
        <Route path="/mainpg" element={<MainPG />} />
      </Routes>
    </Router>
  );
}

export default App;
